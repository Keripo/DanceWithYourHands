//This javascript function creates JS Hashes
//Comma separated key value pairs need to be passed to this Hash contructor

function Hash()
{
    var len = Hash.arguments.length;
    if(len %2 == 1)
    {
        return;
    }
    for(i=0; i<len; i=i+2)
    {
        eval("this['" + Hash.arguments[i] + "']='" + Hash.arguments[i+1] + "';");
    }
}
